'''
script for creating emotion feature for the tweets analysis.
will be run every month.
8.8.18 by ofir & yogev
'''

#Imports
import pandas as pd
import csv
import requests
import os
from tqdm import tqdm , tqdm_pandas
os.chdir('../support algo')

tqdm.pandas()

def read_data(file,start=False):
    #Reading the data function- if start: read from the relevance algo output. else: from emotion_df which is updating every month
    if start:
        tweet_df = pd.read_csv("../data/{}".format(file), header=0, sep='\t',
                           quoting=csv.QUOTE_NONE, encoding='utf-8')
        tweet_df = tweet_df[['id', 'text', 'relevance']]
    else:
        tweet_df = pd.read_pickle("emotion_df.pkl")
        tweet_df = tweet_df[['id', 'text', 'relevance', 'emotion']]
    raw_nrow = tweet_df.shape[0]
    print('Total number of tweets: {}'.format(raw_nrow))
    return tweet_df

def filter_irrelevance(df):
    #remove irrelevant tweets from data frame
    irrelevant_df = df[df['relevance']==1]
    df = df[df['relevance']!=1]
    print('Total number of relevant tweets: {}'.format(df.shape[0]))
    df = df.reset_index(drop=True)
    #return the both dfs for merging at the end
    return df, irrelevant_df

def filter_tagging(df, start=False):
    #filter by the emotion field. if none-> need to create emotion filter.
    if start:
        df['emotion'] = None
    with_emotion = df[df['emotion'].isnull() == False]       #not need to tag
    print('# of emotion untill now: ' , with_emotion.shape[0])
    without_emotion = df[df['emotion'].isnull()]             #option of tagging
    tag_emotion = df.sample(n=2500)                          #send only 2500 tweets to watson
    return with_emotion, without_emotion, tag_emotion

def clean_tweet_emotion(text):
    '''
    Utility function to clean the text in a tweet by removing
    links and special characters using regex, and correct spelling errors.
    '''
    text = text.lower()
    cleaned_tweet = ''
    for word in text.split():
        if ('pic.twitter' not in word
        and 'http' not in word and not word.startswith('@')
        and not word.startswith('#')
        and not word.startswith('bit.ly')
        and not word.startswith('bitly')
        and 'rt' not in word):
            cleaned_tweet += (' '+word)
    return ' '.join(cleaned_tweet.split())

def normalize_text(df):
    df['noramlized_text_emotion'] = df['text'].apply(lambda x: clean_tweet_emotion(x))
    return df

def analyze_tone(text, user):
    global counter
    #IBM account by user
    if user=='yogev':
        username = 'e91c9dc9-cd8b-4dec-ada9-c20e9609cad7'
        password = 'DgyX5YGokb2Q'
    elif user=='ofir':
        username = 'e20665e9-7538-4c8d-b81d-fcb03dbe4225'
        password = 'xxN4jLNbxYVo'
    elif user=='michal':
        username = 'ae540f7a-b2f1-4ccd-8bfc-a66d730eff72'
        password = 'n2OGpWibl0je'
    elif user=='dor':
        username = 'a644f0ee-30c0-4234-bb2b-56262a9c66de'
        password = 'ovXDcFa3khfv'
    elif user=='david':
        username = '4eb8e43c-b835-4133-8ef5-bfdb50a33b35'
        password = 'aaI4cHcpdRf7'
    elif user=='yair':
        username = '9c56d241-3dc8-4acf-991c-cab4f59e4af1'
        password = 'bShvQG433D8f'
    elif user=='roi':
        username = 'e4cd1b72-5b66-456b-9598-83f4763c7ba5'
        password = '5clOYuVPC2Jc'
    elif user=='alon':
        username = '5492ce41-23c6-4f4b-bd3c-107a62803e48'
        password = 'cyiO1NgKo0uA'
    elif user=='shira':
        username = '5928ec34-d1aa-4ff8-ae68-3fe007687900'
        password = 'UIPiu0fFNb1f'
    watsonUrl = "https://gateway.watsonplatform.net/tone-analyzer/api/v3/tone?version=2016-05-19"
    headers = {"content-type": "text/plain"}
    data = text
    try:
        #get watson service
        r = requests.post(watsonUrl, auth=(username,password),headers=headers, data=data)
        return r.text
    except:
        counter+=1
        return None

def emotion(text,user):
    #function which apply the tone analyzer
    results = analyze_tone(text,user)
    return results

def watson(df,user):
    #normalize text-> input for watson
    df = normalize_text(df)
    print('Normalized was done')
    print('Start analyze emotion')
    #analyze each text by emotion
    df['emotion'] = df['noramlized_text_emotion'].apply(lambda x: emotion(x,user))
    print('emotion feature was created')
    df = df.drop('noramlized_text_emotion', axis=1)
    return df

def main(user):
    #Reading original data only at start
    file = 'data_w_relevance.tsv'
    start = False
    df = read_data(file, start)
    #split data for two seperate df: relevant & irrelevant
    relevant_df, irrelevant_df = filter_irrelevance(df)
    # split relevants tweets for 3 seperate df: with emotion (what is tagged already), without (need to be tagged) and
     # tag emotion (has been chosen to be tagged
    with_emotion, without_emotion, tag_emotion = filter_tagging(relevant_df, start)
    #watson analyzer- IBM
    tag_emotion = watson(tag_emotion,user)
    #union of all df
    df= pd.concat([with_emotion,without_emotion,tag_emotion,irrelevant_df])
    df = df.reset_index(drop=True)
    #Export for the support algo
    df.to_pickle('emotion_df.pkl')
    return df

#Users who have tone analyzer service
user_list= ['yogev', 'ofir','michal', 'dor', 'david', 'yair', 'roi', 'alon', 'shira']
#create emotion feature for each user
for user in tqdm(user_list):
    counter = 0
    main(user)
    print('user {} with {} errors'.format(user, counter))