import pandas as pd
import numpy as np

def add_cencus_data(df, config):
    print('START: Census data - TBD')

    # Filter to only US locations
    print('TBD')
    # Extract user city

    print('COMPLETED: Census data - TBD')
    return df